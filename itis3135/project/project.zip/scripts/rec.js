


$(function(){
    $("#move").draggable({
    });
});


$(function(){
    $("#move2").draggable({
    });
});


