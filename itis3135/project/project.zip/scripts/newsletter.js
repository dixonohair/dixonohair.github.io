

//newsletter form 

//date picker widget
$(function(){
    $("#date").datepicker({
        changeMonth: true,
        changeYear: true
    });
});





