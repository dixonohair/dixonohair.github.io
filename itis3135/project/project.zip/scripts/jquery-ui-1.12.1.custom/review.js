
//archordian widget for review page

$(document).ready(function() {
    $("#tab").accordion({
        
        event:"click",
        heightStyle: "content",
        collapsible: true
        
    });
});